-- -------------------------------------------------
-- 				데이터베이스 초기화 및 생성, 사용
-- -------------------------------------------------
drop database if exists academy_db;

create database academy_db;

use academy_db;

-- -------------------------------------------------
-- 						테이블 생성
-- -------------------------------------------------
create table notice(
	notice_id int primary key auto_increment,
    notice_title varchar(50) not null,
    notice_content varchar(500) not null,
    notice_date timestamp default now()
);

insert into notice values(null, "클라우드 기반 인공지능 개발과 DevOps 실무 과정", "선수학습 대상 : 훈련과정 참여 인원", default);
insert into notice values(null, "라이다 및 영상인식기반 모빌리티 자율주행 솔루션 실무과정 선수학습 공지사항", "선수학습 대상 : 훈련과정 참여 인원 中 비전공자 및 비경력자", default);

select notice_id, notice_title, notice_content, date_format(notice_date, "%Y-%m-%d")as notice_date from notice order by notice_date desc;

