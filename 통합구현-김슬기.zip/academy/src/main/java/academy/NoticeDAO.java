package academy;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class NoticeDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	// 공지사항DB 접속
	public NoticeDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/academy_db";	// MySQL 주소 
			String dbID = "root";	//MySQL ID
			String dbPassword = "root";	//MySQL PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);	//DB 접속
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// 공지사항 불러오기
	// Database 테이블 불러오기
		public ArrayList<Notice> getList(){
			String SQL = "select notice_id, notice_title, notice_content, date_format(notice_date, \"%Y-%m-%d\")as notice_date from notice order by notice_date desc;";
			
			ArrayList<Notice> list = new ArrayList<Notice>();
			try {
				PreparedStatement pstmt = conn.prepareStatement(SQL);
				rs=pstmt.executeQuery();
				while(rs.next()) {
					Notice academy = new Notice();
					academy.setNotice_id(rs.getInt(1));
					academy.setNotice_title(rs.getString(2));
					academy.setNotice_content(rs.getString(3));
					academy.setNotice_date(rs.getString(4));
					list.add(academy);
				}
			}catch(Exception e) {
				e.printStackTrace();
			}
			return list;
		}
}
