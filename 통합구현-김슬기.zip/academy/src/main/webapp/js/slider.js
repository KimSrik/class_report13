// 슬라이더 변경 함수
function ChangeSlider(num){
  let slide = document.querySelectorAll('.slide');
  let cIdx;
  for(let idx=0; idx<slide.length; idx++){
    if(slide[idx].classList.contains('active')){
      cIdx = idx;
    }
    slide[idx].classList.remove('active');
  }
  if(num<0){
    if(cIdx == 0){
        cIdx = 3;
    }
    cIdx = cIdx - 1;
  }else{
      cIdx = (cIdx + num) % 3;
  }                
  slide[cIdx].classList.add("active");
}

// 이전 버튼
document.querySelector('.btn-prev').onclick = function(){
  ChangeSlider(-1);
}
// 다음 버튼
document.querySelector('.btn-next').onclick = function(){
  ChangeSlider(1);
}
// 3초마다 자동으로 슬라이더 변경 함수 호출
setInterval(function(){
  ChangeSlider(1);
},3000);